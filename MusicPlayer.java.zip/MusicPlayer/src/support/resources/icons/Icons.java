package support.resources.icons;

public class Icons {
}
